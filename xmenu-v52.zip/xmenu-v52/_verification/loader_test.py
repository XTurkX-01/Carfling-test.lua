#!/usr/bin/env python3
"""
LOADER.lua uçtan uca testi:

    raw GitHub URL  →  game:HttpGet  →  loadstring  →  arayüz oluşuyor

Sahte ortam (runtime_test.MOCK) kullanılır; chunk GLOBAL ortamda çalıştığı
için servisler global'e açılır (Roblox'ta chunk global ortamda çalışır).
"""
import pathlib
import re
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))

import runtime_test as rt  # noqa: E402  (MOCK tanımı)

MOCK_URL = "https://mock.local/xmenu/XMENU_V52_CLIENT_UI.raw.lua"

raw = (ROOT / "XMENU_V52_CLIENT_UI.raw.lua").read_text(encoding="utf-8")
loader = (ROOT / "LOADER.lua").read_text(encoding="utf-8")

# Harness: chunk global ortamda çalışıyor, _G CLI'da salt-okunur.
raw_for_test = raw.replace(
    "local sharedGlobals: any = _G", "local sharedGlobals: any = LOADER_MOCK_GLOBALS"
)

# Loader'daki gerçek URL'yi mock URL ile değiştir.
if "https://raw.githubusercontent.com/KULLANICI/DEPO/main/XMENU_V52_CLIENT_UI.raw.lua" not in loader:
    raise SystemExit("LOADER.lua içindeki örnek URL bulunamadı")
loader = loader.replace(
    "https://raw.githubusercontent.com/KULLANICI/DEPO/main/XMENU_V52_CLIENT_UI.raw.lua",
    MOCK_URL,
)

if "]==]" in raw_for_test:
    raise SystemExit("raw kaynakta ]==] dizisi var, uzun string kaçışı bozulur")

# chunk GLOBAL ortamda çalışıyor (Roblox'taki gibi) → mock'un Roblox
# benzeri tanımları global'e çevrilir, böylece chunk onları görebilir.
GLOBALISE = (
    "Players|RephicatedStorage|ReplicatedStorage|Lighting|SoundService|Workspace|"
    "RunService|UserInputService|TweenService|StarterGui|Instance|TweenInfo|"
    "Enum|Color3|UDim2|UDim|Vector2"
)

EXPORT = """
LOADER_MOCK_GLOBALS = {}
"""

GAME_MOCK = """
local SERVICES = {
	Players = Players,
	ReplicatedStorage = ReplicatedStorage,
	Lighting = Lighting,
	SoundService = SoundService,
	UserInputService = UserInputService,
	RunService = RunService,
	TweenService = TweenService,
	Workspace = Workspace,
}

game = {}

function game:GetService(name: string): any
	local service = SERVICES[name]
	if service == nil then
		error("bilinmeyen servis: " .. tostring(name))
	end
	return service
end

local fetchedUrl = nil

function game:HttpGet(url: string): string
	fetchedUrl = url
	return MOCK_RAW_SOURCE
end
"""

CHECKS = """
local failures = {}
local total = 0

local function check(name: string, cond: boolean, detail: any)
	total += 1
	if cond then
		print("  ✓ " .. name)
	else
		table.insert(failures, name .. " (" .. tostring(detail) .. ")")
		print("  ✗ " .. name .. " → " .. tostring(detail))
	end
end

check("HttpGet mock URL'i çağrıldı", fetchedUrl == MOCK_URL_EXPECTED, fetchedUrl)
check("fetch edilen kaynak boş değil", type(MOCK_RAW_SOURCE) == "string" and #MOCK_RAW_SOURCE > 1000, #MOCK_RAW_SOURCE)

local loaderGui = LocalPlayer:WaitForChild("PlayerGui")

local uiFound = false
for _, descendant in ipairs(loaderGui:GetDescendants()) do
	if descendant.Name == "UIKitGui" then
		uiFound = true
		break
	end
end
check("loadstring sonrası arayüz oluştu", uiFound)

local registry = LOADER_MOCK_GLOBALS["XMENU_V52_CLIENT_UI"]
check(
	"temizlik kaydı oluştu",
	type(registry) == "table" and type(registry.Cleanup) == "function"
)

print(string.format("kontrol sayısı: %d", total))
if #failures == 0 then
	print("TÜM TESTLER GEÇTİ")
else
	for _, failure in ipairs(failures) do
		print("BAŞARISIZ: " .. failure)
	end
	error("loader testi başarısız")
end
"""

mock_for_loader = re.sub(
    r"^local (" + GLOBALISE + r") =", r"\1 =", rt.MOCK, flags=re.M
)

script = (
    mock_for_loader
    + "\n"
    + EXPORT
    + "\nMOCK_RAW_SOURCE = [==[\n"
    + raw_for_test
    + "\n]==]\n"
    + GAME_MOCK
    + "\nMOCK_URL_EXPECTED = "
    + f'"{MOCK_URL}"'
    + "\n"
    + loader
    + "\n"
    + CHECKS
)

out = HERE.parent / ".check" / "loader_test.luau"
out.parent.mkdir(exist_ok=True)
out.write_text(script, encoding="utf-8")

proc = subprocess.run(
    [str(rt.tool("luau")), str(out)], capture_output=True, text=True
)
print(proc.stdout.strip())
if proc.stderr.strip():
    print("STDERR:", proc.stderr.strip()[:2000])
    sys.exit(1)
if "TÜM TESTLER GEÇTİ" not in proc.stdout:
    sys.exit(1)
print("RESULT: all clean")
