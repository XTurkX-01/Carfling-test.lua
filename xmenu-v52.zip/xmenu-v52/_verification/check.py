#!/usr/bin/env python3
"""
Type-check harness for the X MENU V52 client UI files.

luau-analyze has no Roblox API definitions, so each file is analysed as a
"shadow": a prelude of Roblox API stubs (+ the UIKit module contract) followed
by the real body with require()/GetService() redirected to the stubs.
"""
import pathlib
import re
import shutil
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE.parent / ".check"

API = r'''
-- ===== Roblox API stubs (harness only) =====
type RBXScriptConnection = { Disconnect: (RBXScriptConnection) -> () }
type RBXScriptSignal = { Connect: (RBXScriptSignal, (...any) -> ()) -> RBXScriptConnection }
type UIStroke = { Name: string?, Parent: any, Color: any, Thickness: number, Transparency: number, Enabled: boolean }
type UIScale = { Name: string?, Parent: any, Scale: number }
type Gui = {
	Name: string?,
	Parent: any,
	Text: string,
	Size: any,
	Position: any,
	Activated: RBXScriptSignal,
	InputBegan: RBXScriptSignal,
	InputChanged: RBXScriptSignal,
	InputEnded: RBXScriptSignal,
	[string]: any,
}
type Instance = Gui
type Frame = Gui
type TextLabel = Gui
type TextButton = Gui
type ScrollingFrame = Gui
type UICorner = Gui
type UIListLayout = Gui
type UISizeConstraint = Gui
type ScreenGui = Gui
type PlayerGui = Gui
type SoundGroup = { Name: string, Volume: number }
type SoundService = Gui
type Lighting = { Brightness: number, GlobalShadows: boolean, [string]: any }
type Camera = { FieldOfView: number, [string]: any }
type Workspace = { CurrentCamera: Camera?, [string]: any }
type Player = {
	Name: string,
	UserId: number,
	Character: any,
	CameraMaxZoomDistance: number,
	CameraMinZoomDistance: number,
	CharacterAdded: RBXScriptSignal,
	Kick: (any, string?) -> (),
	WaitForChild: (any, string, number?) -> any,
}
type Players = {
	LocalPlayer: Player,
	PlayerAdded: RBXScriptSignal,
	PlayerRemoving: RBXScriptSignal,
	GetPlayers: (any) -> { Player },
}
type RemoteEvent = {
	OnClientEvent: RBXScriptSignal,
	OnServerEvent: RBXScriptSignal,
	FireClient: (any, Player, ...any) -> (),
	FireServer: (any, ...any) -> (),
}
type ReplicatedStorage = Gui
type InputObject = { KeyCode: any, Position: any, UserInputType: any }
type UserInputService = {
	InputBegan: RBXScriptSignal,
	InputChanged: RBXScriptSignal,
	InputEnded: RBXScriptSignal,
}
type RunService = { Heartbeat: RBXScriptSignal }
type KeyCode = any
type StarterGui = { SetCore: (any, string, any) -> () }
type TweenInfo = { new: (...any) -> any }
type TweenService = { Create: (any, any, any, any) -> any }

local Instance = {
	new = function(_className: string): any
		return {}
	end,
}
local Enum: any = nil :: any
local UDim2: any = nil :: any
local UDim: any = nil :: any
local Color3: any = nil :: any
local Vector2: any = nil :: any
local Vector3: any = nil :: any
local warn: (...any) -> () = function(...: any): () end
local task: {
	wait: (number?) -> number,
	spawn: (...any) -> any,
	delay: (number, (...any) -> ()) -> any,
	defer: (...any) -> any,
} = {
	wait = function(_s: number?): number return 0 end,
	spawn = function(_f: any): any return nil end,
	delay = function(_s: number, _f: any): any return nil end,
	defer = function(_f: any, ...: any): any return nil end,
}

local function newSignal(): RBXScriptSignal
	return {
		Connect = function(_s: any, _c: any): RBXScriptConnection
			return { Disconnect = function() end }
		end,
	}
end

local function newGui(name: string): Gui
	return {
		Name = name,
		Parent = nil,
		Text = "",
		Size = nil,
		Position = nil,
		Activated = newSignal(),
		InputBegan = newSignal(),
		InputChanged = newSignal(),
		InputEnded = newSignal(),
	}
end

local HARNESS_LocalPlayer: Player = {
	Name = "Tester",
	UserId = 42,
	Character = nil,
	CameraMaxZoomDistance = 128,
	CameraMinZoomDistance = 0.5,
	CharacterAdded = newSignal(),
	Kick = function() end,
}
local HARNESS_HttpGet = function(_url: string): string
	return ""
end
local HARNESS_Players: Players = {
	LocalPlayer = HARNESS_LocalPlayer,
	PlayerAdded = newSignal(),
	PlayerRemoving = newSignal(),
	GetPlayers = function(_s: any): { Player } return { HARNESS_LocalPlayer } end,
}
local HARNESS_Remotes: Gui = {
	UseAbility = { OnServerEvent = newSignal(), OnClientEvent = newSignal(), FireServer = function() end, FireClient = function() end } :: RemoteEvent,
	AbilityResult = { OnServerEvent = newSignal(), OnClientEvent = newSignal(), FireServer = function() end, FireClient = function() end } :: RemoteEvent,
	Notify = { OnServerEvent = newSignal(), OnClientEvent = newSignal(), FireServer = function() end, FireClient = function() end } :: RemoteEvent,
	AdminCommand = { OnServerEvent = newSignal(), OnClientEvent = newSignal(), FireServer = function() end, FireClient = function() end } :: RemoteEvent,
	RequestRejoin = { OnServerEvent = newSignal(), OnClientEvent = newSignal(), FireServer = function() end, FireClient = function() end } :: RemoteEvent,
}
local HARNESS_ReplicatedStorage: ReplicatedStorage = {
	WaitForChild = function(_s: any, name: string, _timeout: number?): any
		if name == "Remotes" then
			return HARNESS_Remotes
		end
		return nil
	end,
	FindFirstChild = function(_s: any, name: string): any
		if name == "Remotes" then
			return HARNESS_Remotes
		end
		return nil
	end,
}
local HARNESS_SoundService: SoundService = {
	GetChildren = function(_s: any): { any }
		return {
			{ Name = "Music", Volume = 0.8 } :: SoundGroup,
			{ Name = "SFX", Volume = 0.9 } :: SoundGroup,
		}
	end,
}
local HARNESS_Lighting: Lighting = { Brightness = 2, GlobalShadows = true }
local HARNESS_Camera: Camera = { FieldOfView = 70 }
local HARNESS_Workspace: Workspace = {
	CurrentCamera = HARNESS_Camera,
	GetPropertyChangedSignal = function(_s: any, _name: string): RBXScriptSignal
		return newSignal()
	end,
}
local HARNESS_UserInputService: UserInputService = {
	InputBegan = newSignal(),
	InputChanged = newSignal(),
	InputEnded = newSignal(),
}
local HARNESS_RunService: RunService = { Heartbeat = newSignal() }
local HARNESS_StarterGui: StarterGui = { SetCore = function() end }
local HARNESS_TweenService: TweenService = {
	Create = function(_s: any, _instance: any, _info: any, _props: any): any
		return { Play = function() end, Completed = newSignal() }
	end,
}
local HARNESS_TweenInfo = { new = function(...: any): any return {} end }
local HARNESS_game: any = nil :: any
'''

UIKIT_STUB = r'''
-- ===== UIKit module contract (must mirror the real UIKit.lua) =====
type UIKitWindow = {
	Frame: Frame,
	Body: Frame,
	SetTitle: (any, string) -> (),
	SetVisible: (any, boolean) -> (),
	IsVisible: (any) -> boolean,
	Destroy: (any) -> (),
}
type UIKitSlider = {
	Frame: Frame,
	GetValue: (any) -> number,
	SetValue: (any, number) -> (),
	Destroy: (any) -> (),
}
type UIKitAbility = { Id: string, Label: string, Duration: number }

local HARNESS_UIKit = {
	toast = function(_message: string, _seconds: number?): () end,
	button = function(_parent: Instance, _text: string, _onActivated: () -> (), _debounce: number?): TextButton
		return newGui("UIKitButton")
	end,
	label = function(_parent: Instance, _text: string): TextLabel
		return newGui("UIKitLabel")
	end,
	window = function(_options: { Title: string, Name: string?, WidthScale: number?, HeightScale: number? }): UIKitWindow
		return {
			Frame = newGui("UIKitWindow"),
			Body = newGui("Body"),
			SetTitle = function() end,
			SetVisible = function() end,
			IsVisible = function() return false end,
			Destroy = function() end,
		}
	end,
	slider = function(_options: { Min: number, Max: number, Step: number, Value: number?, OnChange: (number) -> () }): UIKitSlider
		return {
			Frame = newGui("UIKitSlider"),
			GetValue = function() return 0 end,
			SetValue = function() end,
			Destroy = function() end,
		}
	end,
	getGui = function(): ScreenGui
		return newGui("UIKitGui")
	end,
	abilityBar = function(_abilities: { UIKitAbility }, _useRemote: RemoteEvent, _resultRemote: RemoteEvent): () -> ()
		return function() end
	end,
}
'''

REPLACEMENTS = [
    (r'require\(script\.Parent:WaitForChild\("UIKit"\) :: ModuleScript\) :: any', "HARNESS_UIKit"),
    (r'require\(script\.Parent:WaitForChild\("UIKit"\) :: ModuleScript\)', "HARNESS_UIKit"),
    (r"\{ \[Enum\.KeyCode\]", "{ [KeyCode]"),
    (r'game:HttpGet\(', "HARNESS_HttpGet("),
    (r'game:GetService\("Players"\)', "HARNESS_Players"),
    (r'game:GetService\("ReplicatedStorage"\)', "HARNESS_ReplicatedStorage"),
    (r'game:GetService\("SoundService"\)', "HARNESS_SoundService"),
    (r'game:GetService\("Lighting"\)', "HARNESS_Lighting"),
    (r'game:GetService\("Workspace"\)', "HARNESS_Workspace"),
    (r'game:GetService\("UserInputService"\)', "HARNESS_UserInputService"),
    (r'game:GetService\("RunService"\)', "HARNESS_RunService"),
    (r'game:GetService\("StarterGui"\)', "HARNESS_StarterGui"),
    (r'game:GetService\("TweenService"\)', "HARNESS_TweenService"),
    (r'\bTweenInfo\.new\b', "HARNESS_TweenInfo.new"),
]

FILES = [
    "XMENU_V52_CLIENT_UI.client.lua",
    "XMENU_V52_CLIENT_UI.raw.lua",
    "LOADER.lua",
]

LINE_RE = re.compile(r":(\d+):(\d+)")


def tool(name: str) -> pathlib.Path:
    for candidate in (
        HERE / name,
        HERE.parent / ".tools" / name,
        HERE.parent.parent / ".tools" / name,
    ):
        if candidate.exists():
            return candidate
    found = shutil.which(name)
    if found:
        return pathlib.Path(found)
    raise SystemExit(f"'{name}' bulunamadı: Luau CLI'yi <proje>/.tools/ içine ya da PATH'e koy.")


def main() -> int:
    OUT.mkdir(exist_ok=True)
    failed = False

    for rel in FILES:
        src = ROOT / rel
        body = src.read_text(encoding="utf-8")
        body = body.replace("--!strict", "-- (strict mode header)", 1)
        for pattern, repl in REPLACEMENTS:
            body = re.sub(pattern, repl, body)

        prelude = API
        shadow_text = "--!strict\n" + prelude + "\n" + body
        body_start = shadow_text[: shadow_text.index(body)].count("\n") + 1

        shadow = OUT / (rel.replace("/", "_") + ".check.luau")
        shadow.write_text(shadow_text, encoding="utf-8")

        proc = subprocess.run(
            [str(tool("luau-analyze")), "--formatter=plain", str(shadow)],
            capture_output=True,
            text=True,
        )

        problems = []
        for line in (proc.stdout + proc.stderr).splitlines():
            line = line.strip()
            if not line:
                continue
            m = LINE_RE.search(line)
            if m and int(m.group(1)) < body_start:
                continue  # prelude noise
            problems.append(line.split(".check.luau", 1)[-1])

        if problems:
            failed = True
            print(f"\n===== {rel} =====")
            for p in problems:
                print("  " + p)
        else:
            print(f"OK   {rel}")

    print("\nRESULT:", "FAILED" if failed else "all clean")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
