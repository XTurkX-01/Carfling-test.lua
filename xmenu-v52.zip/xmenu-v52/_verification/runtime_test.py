#!/usr/bin/env python3
"""
Runtime test for the X MENU V52 client UI.

Builds a mock Roblox environment (Instance tree, signals, Players, SoundService,
Lighting, RemoteEvents, virtual clock + scheduler) and executes
UIKit / UIClient / AbilityClient / SettingsClient / AdminClient inside it,
then drives the UI and asserts on behaviour.

Runs twice: once as a NON-admin (admin panel must not exist) and once as an
admin (panel must work).
"""
import pathlib
import re
import shutil
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT / ".check"
CLIENT_DIR = ROOT / "StarterPlayer" / "StarterPlayerScripts"

MOCK = r'''
--!nocheck
-- ===== MOCK ROBLOX ENVIRONMENT =====
local MOCK_TIME = 0
local MOCK_ADMIN_ID = 4242
local mockWarnings = {}
local MOCK_GLOBALS = {}
local mockRemoteCalls = {}
local mockToastCount = 0

-- sanal zamanlayıcı
local scheduled = {}
local function schedule(delay, fn)
	table.insert(scheduled, { at = MOCK_TIME + (delay or 0), fn = fn })
end
local function advanceTime(dt)
	MOCK_TIME += dt
	local due = {}
	for i = #scheduled, 1, -1 do
		if scheduled[i].at <= MOCK_TIME then
			table.insert(due, { at = scheduled[i].at, fn = table.remove(scheduled, i).fn })
		end
	end
	table.sort(due, function(a, b) return a.at < b.at end)
	for _, item in ipairs(due) do
		item.fn()
	end
end

local function newSignal()
	local signal = { handlers = {} }
	function signal:Connect(fn)
		local conn = { Connected = true, _fn = fn }
		function conn:Disconnect()
			self.Connected = false
		end
		table.insert(self.handlers, conn)
		return conn
	end
	function signal:Fire(...)
		local args = table.pack(...)
		for _, conn in ipairs(self.handlers) do
			if conn.Connected then
				conn._fn = conn._fn
				local ok, err = pcall(function()
					conn._fn(table.unpack(args, 1, args.n))
				end)
				if not ok then
					table.insert(mockWarnings, "handler error: " .. tostring(err))
				end
			end
		end
	end
	return signal
end

local function newPropSignal()
	return newSignal()
end

local Instance = {}
Instance.__index = Instance

local function newIndex(t, k, v)
	if k == "Parent" then
		rawset(t, "Parent", v)
		if type(v) == "table" and v._children then
			table.insert(v._children, t)
		end
	else
		rawset(t, k, v)
		local signal = rawget(t, "_propSignals") and rawget(t, "_propSignals")[k]
		if signal then
			signal:Fire(v)
		end
	end
end

function Instance.new(className)
	local self = setmetatable({
		ClassName = className,
		Name = "",
		Parent = nil,
		_children = {},
		_propSignals = {},
	}, { __index = Instance, __newindex = newIndex })

	-- ortak arayüz alanları
	self.Visible = true
	self.BackgroundTransparency = 0
	self.BackgroundColor3 = { R = 0, G = 0, B = 0 }
	self.BorderSizePixel = 0
	self.Size = { X = 0, Y = 0 }
	self.Position = { X = 0, Y = 0 }
	self.AnchorPoint = { X = 0, Y = 0 }
	self.Text = ""
	self.TextSize = 14
	self.TextColor3 = { R = 1, G = 1, B = 1 }
	self.Font = "Gotham"
	self.TextXAlignment = "Left"
	self.TextWrapped = false
	self.TextTransparency = 0
	self.AutomaticSize = "None"
	self.LayoutOrder = 0
	self.ClipsDescendants = false
	self.ZIndex = 1
	self.AbsolutePosition = { X = 0, Y = 0 }
	self.AbsoluteSize = { X = 200, Y = 44 }

	-- her nesne giriş sinyallerine sahip olabilir (kaydırıcı parmağı vb.)
	self.InputBegan = newSignal()
	self.InputChanged = newSignal()
	self.InputEnded = newSignal()
	self.MouseEnter = newSignal()
	self.MouseLeave = newSignal()

	if className == "TextButton" or className == "ImageButton" then
		self.Activated = newSignal()
		self.AutoButtonColor = true
	end
	if className == "ScreenGui" then
		self.ResetOnSpawn = true
		self.DisplayOrder = 0
	end
	if className == "UISizeConstraint" then
		self.MinSize = { X = 0, Y = 0 }
		self.MaxSize = { X = 0, Y = 0 }
	end
	if className == "UIListLayout" then
		self.Padding = { X = 0, Y = 0 }
		self.SortOrder = "LayoutOrder"
	end
	if className == "UICorner" then
		self.CornerRadius = { X = 0, Y = 0 }
	end
	if className == "ScrollingFrame" then
		self.ScrollBarThickness = 4
		self.AutomaticCanvasSize = "None"
	end
	return self
end

function Instance:IsA(className)
	return self.ClassName == className
end
function Instance:FindFirstChild(name)
	for _, c in ipairs(self._children) do
		if c.Name == name then
			return c
		end
	end
	return nil
end
function Instance:WaitForChild(name)
	local c = self:FindFirstChild(name)
	if c then
		return c
	end
	error("WaitForChild: '" .. tostring(name) .. "' not found")
end
function Instance:GetChildren()
	return self._children
end
function Instance:GetDescendants()
	local out = {}
	local function walk(node)
		for _, c in ipairs(node._children) do
			table.insert(out, c)
			walk(c)
		end
	end
	walk(self)
	return out
end
function Instance:GetPropertyChangedSignal(name)
	local signals = rawget(self, "_propSignals")
	if signals[name] == nil then
		signals[name] = newPropSignal()
	end
	return signals[name]
end
function Instance:Clone()
	local copy = Instance.new(self.ClassName)
	copy.Name = self.Name
	return copy
end
function Instance:Destroy()
	if self.Parent then
		for i, c in ipairs(self.Parent._children) do
			if c == self then
				table.remove(self.Parent._children, i)
				break
			end
		end
	end
end

-- uzaklık: metin veya isimle bul
local function findByText(root, text)
	for _, d in ipairs(root:GetDescendants()) do
		if d.Text == text then
			return d
		end
	end
	return nil
end
local function findByName(root, name)
	for _, d in ipairs(root:GetDescendants()) do
		if d.Name == name then
			return d
		end
	end
	return nil
end
local function click(instance)
	assert(instance ~= nil, "click: instance yok")
	instance.Activated:Fire()
end

--[[ Oyuncular ]]
local playersList = {}
local Players = {
	PlayerAdded = newSignal(),
	PlayerRemoving = newSignal(),
	GetPlayers = function(_s)
		return playersList
	end,
}
local LocalPlayer = Instance.new("Player")
LocalPlayer.Name = "Tester"
LocalPlayer.UserId = 1
LocalPlayer.CharacterAdded = newSignal()
LocalPlayer.CameraMaxZoomDistance = 128
LocalPlayer.CameraMinZoomDistance = 0.5
LocalPlayer.Kick = function() end
Players.LocalPlayer = LocalPlayer
table.insert(playersList, LocalPlayer)

--[[ RemoteEvent ]]
local function newRemote(name)
	local remote = Instance.new("RemoteEvent")
	remote.Name = name
	remote.OnServerEvent = newSignal()
	remote.OnClientEvent = newSignal()
	remote.FireServer = function(_s, ...)
		table.insert(mockRemoteCalls, { remote = name, args = table.pack(...) })
		remote.OnServerEvent:Fire(...)
	end
	remote.FireClient = function(_s, _player, ...)
		table.insert(mockRemoteCalls, { remote = name, args = table.pack(...) })
		remote.OnClientEvent:Fire(...)
	end
	return remote
end

local RemotesFolder = Instance.new("Folder")
RemotesFolder.Name = "Remotes"
RemotesFolder.Parent = nil
local UseAbility = newRemote("UseAbility")
local AbilityResult = newRemote("AbilityResult")
local Notify = newRemote("Notify")
local AdminCommand = newRemote("AdminCommand")
local RequestRejoin = newRemote("RequestRejoin")
for _, r in ipairs({ UseAbility, AbilityResult, Notify, AdminCommand, RequestRejoin }) do
	r.Parent = RemotesFolder
end

local ReplicatedStorage = Instance.new("Folder")
ReplicatedStorage.Name = "ReplicatedStorage"
RemotesFolder.Parent = ReplicatedStorage

--[[ Servisler ]]
local Music = Instance.new("SoundGroup")
Music.Name = "Music"
Music.Volume = 0.8
local SFX = Instance.new("SoundGroup")
SFX.Name = "SFX"
SFX.Volume = 0.9
local SoundService = Instance.new("Folder")
SoundService.Name = "SoundService"
Music.Parent = SoundService
SFX.Parent = SoundService

local Lighting = Instance.new("Folder")
Lighting.Name = "Lighting"
Lighting.Brightness = 2
Lighting.GlobalShadows = true

local Camera = Instance.new("Camera")
Camera.FieldOfView = 70
local Workspace = Instance.new("Folder")
Workspace.Name = "Workspace"
Workspace.CurrentCamera = Camera
Camera.Parent = Workspace

local UserInputService = Instance.new("Folder")
UserInputService.InputBegan = newSignal()
UserInputService.InputChanged = newSignal()
UserInputService.InputEnded = newSignal()

local RunService = Instance.new("Folder")
RunService.Heartbeat = newSignal()

local StarterGui = Instance.new("Folder")
StarterGui.SetCore = function() end

local TweenInfo = { new = function(...) return { duration = 0.18 } end }
local TweenService = {
	Create = function(_s, _instance, _info, _props)
		local tween = { Played = false }
		tween.Completed = newSignal()
		tween.Play = function()
			tween.Played = true
			tween.Completed:Fire()
		end
		return tween
	end,
}

local Enum = {
	KeyCode = {
		Z = "KeyCode.Z",
		X = "KeyCode.X",
		C = "KeyCode.C",
		V = "KeyCode.V",
	},
	Font = { Gotham = "Gotham", GothamBold = "GothamBold", GothamSemibold = "GothamSemibold", GothamMedium = "GothamMedium" },
	TextXAlignment = { Left = "Left", Center = "Center", Right = "Right" },
	HorizontalAlignment = { Center = "Center" },
	VerticalAlignment = { Center = "Center" },
	SortOrder = { LayoutOrder = "LayoutOrder" },
	FillDirection = { Horizontal = "Horizontal", Vertical = "Vertical" },
	AutomaticSize = { Y = "Y", None = "None" },
	UserInputType = { MouseMovement = "MouseMovement", Touch = "Touch" },
	EasingStyle = { Quad = "Quad", Linear = "Linear" },
	EasingDirection = { Out = "Out", In = "In" },
}

local Color3 = { fromRGB = function(r, g, b) return { R = r, G = g, B = b } end }
local UDim2 = {
	new = function(x, y, x2, y2) return { X = x, Y = y, X2 = x2, Y2 = y2 } end,
	fromScale = function(x, y) return { X = x, Y = y, X2 = x, Y2 = y } end,
	fromOffset = function(x, y) return { X = x, Y = y, X2 = x, Y2 = y } end,
}
local UDim = { new = function(x, y) return { X = x, Y = y } end }
local Vector2 = { new = function(x, y) return { X = x, Y = y } end }
local Vector3 = { new = function(x, y, z) return { X = x, Y = y, Z = z } end }

local os = { clock = function() return MOCK_TIME end, time = os.time }
local warn = function(...)
	local parts = {}
	for i = 1, select("#", ...) do
		table.insert(parts, tostring(select(i, ...)))
	end
	table.insert(mockWarnings, table.concat(parts, " "))
end
local task = {
	wait = function(dt) advanceTime(dt or 0) end,
	spawn = function(fn, ...) fn(...) end,
	delay = function(delay, fn) schedule(delay, fn) end,
	defer = function(fn, ...)
		local args = table.pack(...)
		schedule(0, function() fn(table.unpack(args, 1, args.n)) end)
	end,
}
local Players = Players

-- PlayerGui (client'in arayüzleri buraya eklenir)
local PlayerGui = Instance.new("PlayerGui")
PlayerGui.Name = "PlayerGui"
PlayerGui.Parent = LocalPlayer
'''

TEST = r'''
-- ===== TEST DRIVER =====
local failures = {}
local totalChecks = 0
if UIKitModule == nil then
	print("--- uyarılar ---")
	for _, w in ipairs(mockWarnings) do
		print("  " .. w)
	end
	error("UIKit yüklenmedi (chunk hatası)")
end
local function check(name, cond, detail)
	totalChecks += 1
	if not cond then
		table.insert(failures, name .. (detail and (" -> " .. tostring(detail)) or ""))
	end
end

local function remoteCalls(name)
	local out = {}
	for _, call in ipairs(mockRemoteCalls) do
		if call.remote == name then
			table.insert(out, call.args)
		end
	end
	return out
end
local function clearCalls()
	mockRemoteCalls = {}
end

local gui = LocalPlayer:WaitForChild("PlayerGui")
if gui == nil then
	gui = Instance.new("PlayerGui")
	gui.Name = "PlayerGui"
	gui.Parent = LocalPlayer
end

-- ==========================================================
-- UIKit
-- ==========================================================
local kitGui = findByName(gui, "UIKitGui")
check("UIKit ScreenGui oluştu", kitGui ~= nil)
check("UIKit ResetOnSpawn=false", kitGui ~= nil and kitGui.ResetOnSpawn == false)

-- toast sınırı (en fazla 3)
for i = 1, 4 do
	UIKitModule.toast("mesaj " .. i)
end
local toasts = 0
for _, d in ipairs(gui:GetDescendants()) do
	if d.Name == "Toast" then
		toasts += 1
	end
end
check("toast en fazla 3 tane", toasts == 3, toasts)

-- toast süre sonunda kalkar
advanceTime(3.1)
toasts = 0
for _, d in ipairs(gui:GetDescendants()) do
	if d.Name == "Toast" then
		toasts += 1
	end
end
check("toast süre sonunda kalktı", toasts == 0, toasts)

-- buton debounce
local pressCount = 0
local probe = Instance.new("TextButton")
probe.Parent = gui
UIKitModule.button(probe, "Probe", function()
	pressCount += 1
end)
local probeButton = findByText(probe, "Probe")
click(probeButton)
click(probeButton)
check("buton debounce iki basışı engelledi", pressCount == 1, pressCount)
advanceTime(0.3)
click(probeButton)
check("debounce sonrası tekrar basılıyor", pressCount == 2, pressCount)

-- cooldown butonu
local cd = UIKitModule.cooldownButton(probe, "CD", function() end)
cd:Start(10)
check("cooldown başladı", cd:IsReady() == false)
advanceTime(10.1)
check("cooldown bitti", cd:IsReady() == true)
cd:SetActive(5)
check("aktif çerçevesi kuruldu", cd:IsReady() == true)

-- ==========================================================
-- UIClient: yetenek çubuğu
-- ==========================================================
local bar = findByName(gui, "AbilityBar")
check("yetenek çubuğu oluştu", bar ~= nil)
local speedButton = findByText(bar, "Hız")
check("hız butonu var", speedButton ~= nil)
clearCalls()
click(speedButton)
local calls = remoteCalls("UseAbility")
check("buton yalnızca yetenek adı yolladı", #calls == 1 and calls[1].n == 1 and calls[1][1] == "SpeedBoost", #calls)

-- server cevabı: başarılı -> cooldown başlar
clearCalls()
local cdButtons = {}
for _, d in ipairs(bar:GetChildren()) do
	table.insert(cdButtons, d)
end
AbilityResult:FireClient(LocalPlayer, "SpeedBoost", true, "OK", 20)
local overlay = findByName(speedButton, "Cooldown")
check("başarılı cevap cooldown katmanını gösterdi", overlay ~= nil and overlay.Size ~= nil)

-- server cevabı: Dead -> toast
local before = 0
for _, d in ipairs(gui:GetDescendants()) do
	if d.Name == "Toast" then
		before += 1
	end
end
AbilityResult:FireClient(LocalPlayer, "Heal", false, "Dead", 0)
local after = 0
for _, d in ipairs(gui:GetDescendants()) do
	if d.Name == "Toast" then
		after += 1
	end
end
check("Dead cevabı toast gösterdi", after == before + 1, after - before)

-- ==========================================================
-- AbilityClient: klavye + çift bildirim yok
-- ==========================================================
clearCalls()
UserInputService.InputBegan:Fire({ KeyCode = Enum.KeyCode.Z, Position = { X = 0, Y = 0 } }, false)
calls = remoteCalls("UseAbility")
check("Z tuşu SpeedBoost yolladı", #calls == 1 and calls[1][1] == "SpeedBoost", #calls)

UserInputService.InputBegan:Fire({ KeyCode = Enum.KeyCode.Z, Position = { X = 0, Y = 0 } }, false)
calls = remoteCalls("UseAbility")
check("klavye debounce çalıştı", #calls == 1, #calls)

advanceTime(0.3)
UserInputService.InputBegan:Fire({ KeyCode = Enum.KeyCode.X, Position = { X = 0, Y = 0 } }, false)
calls = remoteCalls("UseAbility")
check("X tuşu HighJump yolladı", #calls == 2 and calls[2][1] == "HighJump", #calls)

-- AbilityClient artık AbilityResult dinlemiyor: çift bildirim olmamalı
local before2 = 0
for _, d in ipairs(gui:GetDescendants()) do
	if d.Name == "Toast" then
		before2 += 1
	end
end
AbilityResult:FireClient(LocalPlayer, "Heal", false, "Cooldown", 10)
local after2 = 0
for _, d in ipairs(gui:GetDescendants()) do
	if d.Name == "Toast" then
		after2 += 1
	end
end
check("AbilityClient çift bildirim üretmiyor", after2 == before2, after2 - before2)

-- ==========================================================
-- SettingsClient
-- ==========================================================
local settingsButton = findByName(gui, "SettingsButton")
check("ayarlar düğmesi var", settingsButton ~= nil)
click(settingsButton)
local window = findByName(gui, "SettingsWindow")
check("ayarlar penceresi açıldı", window ~= nil and window.Visible == true)

-- kaydırıcı sürükleme (müzik %50)
local function dragSliderTo(sliderFrame, ratio)
	local track = findByName(sliderFrame, "Track")
	track.AbsolutePosition = { X = 0, Y = 0 }
	track.AbsoluteSize = { X = 200, Y = 8 }
	local thumb = findByName(sliderFrame, "Thumb")
	thumb.InputBegan:Fire({ Position = { X = 200 * ratio, Y = 0 }, UserInputType = "MouseMovement" })
end

local sliders = {}
for _, d in ipairs(window:GetDescendants()) do
	if d.Name == "UIKitSlider" then
		table.insert(sliders, d)
	end
end
check("ayarlar penceresinde 6 kaydırıcı oluştu", #sliders == 6, #sliders)

dragSliderTo(sliders[1], 0.5)
check("müzik kaydırıcısı ses grubunu ayarladı", math.abs(Music.Volume - 0.5) < 0.001, Music.Volume)
dragSliderTo(sliders[2], 0.25)
check("efekt kaydırıcısı ses grubunu ayarladı", math.abs(SFX.Volume - 0.25) < 0.001, SFX.Volume)

-- parlaklık (kaydırıcı 3. bölüm)
dragSliderTo(sliders[3], 0.5)
check("parlaklık uygulandı", math.abs(Lighting.Brightness - 2) < 0.01, Lighting.Brightness)

-- FOV (kaydırıcı 5. bölüm)
dragSliderTo(sliders[5], 0.5)
check("FOV uygulandı", math.abs(Camera.FieldOfView - 80) < 0.01, Camera.FieldOfView)

-- hiçbir remote çağrılmadı
clearCalls()
check("ayarlar hiçbir remote çağırmadı", #remoteCalls("UseAbility") == 0 and #remoteCalls("AdminCommand") == 0)

-- yeniden bağlan butonu
clearCalls()
local rejoinButton = findByText(window, "Yeniden bağlan")
check("yeniden bağlan butonu var", rejoinButton ~= nil)
click(rejoinButton)
calls = remoteCalls("RequestRejoin")
check("rejoin butonu remote'u çağırdı", #calls == 1 and calls[1].n == 0, #calls)

-- varsayılana dön
click(findByText(window, "Varsayılana dön"))
check("varsayılan müzik sesine dönüldü", math.abs(Music.Volume - 0.8) < 0.001, Music.Volume)
check("varsayılan FOV'a dönüldü", math.abs(Camera.FieldOfView - 70) < 0.01, Camera.FieldOfView)

-- yeniden doğunca ayarlar yeniden uygulanır
dragSliderTo(sliders[5], 1)
check("FOV değişti", math.abs(Camera.FieldOfView - 100) < 0.01, Camera.FieldOfView)
LocalPlayer.CharacterAdded:Fire(Instance.new("Model"))
advanceTime(0.1)
check("yeniden doğunca FOV korundu", math.abs(Camera.FieldOfView - 100) < 0.01, Camera.FieldOfView)

-- ==========================================================
-- AdminClient
-- ==========================================================
if MOCK_ADMIN_ID == LocalPlayer.UserId then
	local adminButton = findByName(gui, "AdminButton")
	check("yönetim düğmesi var", adminButton ~= nil)
	if adminButton == nil then
		print("--- uyarılar ---")
		for _, w in ipairs(mockWarnings) do
			print("  " .. w)
		end
		error("admin arayüzü oluşmadı")
	end
	click(adminButton)
	local adminWindow = findByName(gui, "AdminWindow")
	check("yönetici penceresi açıldı", adminWindow ~= nil and adminWindow.Visible == true)
	if adminWindow == nil then
		for _, w in ipairs(mockWarnings) do
			print("  " .. w)
		end
		error("admin penceresi yok")
	end

	-- hedef seçimi (Player.Name kullanılır)
	local targetButton = findByText(adminWindow, "Ali")
	check("hedef listesi oyuncu adıyla", targetButton ~= nil)
	click(targetButton)

	-- tp hedefle
	clearCalls()
	click(findByText(adminWindow, "Oyuncuya ışınlan"))
	calls = remoteCalls("AdminCommand")
	check("tp komutu gitti", #calls == 1 and calls[1][1] == "tp" and calls[1][2] == "Ali", #calls and calls[1][2])

	-- hız: kaydırıcı 50 + uygula
	local speedSlider = findByName(adminWindow, "UIKitSlider")
	dragSliderTo(speedSlider, 0.5)
	clearCalls()
	click(findByText(adminWindow, "Hızı uygula"))
	calls = remoteCalls("AdminCommand")
	check("hız komutu biçimi doğru", #calls == 1 and calls[1][1] == "speed" and calls[1][2] == "50 Ali", calls[1] and calls[1][2])

	-- hız sıfırla
	clearCalls()
	click(findByText(adminWindow, "Hızı sıfırla"))
	calls = remoteCalls("AdminCommand")
	check("hız sıfırlama komutu doğru", #calls == 1 and calls[1][2] == "reset Ali", calls[1] and calls[1][2])

	-- tanrı modu
	clearCalls()
	click(findByText(adminWindow, "Tanrı modu: kapalı"))
	calls = remoteCalls("AdminCommand")
	check("god komutu doğru", #calls == 1 and calls[1][1] == "god" and calls[1][2] == "on Ali", calls[1] and calls[1][2])

	-- iyileştir
	clearCalls()
	click(findByText(adminWindow, "İyileştir"))
	calls = remoteCalls("AdminCommand")
	check("heal komutu doğru", #calls == 1 and calls[1][1] == "heal", calls[1] and calls[1][1])

	-- komut/argüman uzunluk sınırları
	for _, call in ipairs(remoteCalls("AdminCommand")) do
		check("komut 20 karakterden kısa", #call[1] <= 20, call[1])
		check("argüman 100 karakterden kısa", #call[2] <= 100, call[2])
	end

	-- cevap yoksa 3 sn sonra uyarı
	clearCalls()
	click(findByText(adminWindow, "Oyuncuyu yanıma getir"))
	advanceTime(3.2)
	local resultText = findByText(adminWindow, "Sonuç: Yanıt yok (yetkin olmayabilir)")
	check("cevap yoksa uyarı gösterildi", resultText ~= nil)

	-- sunucu cevabı sonucu doldurur
	clearCalls()
	click(findByText(adminWindow, "Oyuncuya ışınlan"))
	Notify:FireClient(LocalPlayer, "Ali ışınlandı.")
	advanceTime(0.1)
	local okResult = findByText(adminWindow, "Sonuç: Ali ışınlandı.")
	check("sunucu cevabı sonuç satırına yazıldı", okResult ~= nil)

	-- admin paneli tek Notify dinleyicisi: bir bildirim
	local toastCount = 0
	for _, d in ipairs(gui:GetDescendants()) do
		if d.Name == "Toast" then
			toastCount += 1
		end
	end
	Notify:FireClient(LocalPlayer, "rejoin uyarısı")
	advanceTime(0.1)
	local toastCount2 = 0
	for _, d in ipairs(gui:GetDescendants()) do
		if d.Name == "Toast" then
			toastCount2 += 1
		end
	end
	check("beklemeyen Notify tek toast üretti", toastCount2 - toastCount == 1, toastCount2 - toastCount)
else
	local adminButton = findByName(gui, "AdminButton")
	check("yetkisiz oyuncuda yönetim düğmesi yok", adminButton == nil)
end

-- ==========================================================
-- Yeniden çalıştırma temizliği
-- ==========================================================
local registry = MOCK_GLOBALS["XMENU_V52_CLIENT_UI"]
check("temizlik kaydı oluştu", type(registry) == "table" and type(registry.Cleanup) == "function")
if type(registry) == "table" and type(registry.Cleanup) == "function" then
	registry.Cleanup()
	local left = 0
	for _, d in ipairs(gui:GetDescendants()) do
		if d.Name == "UIKitGui" then
			left += 1
		end
	end
	check("temizlik arayüzü kaldırdı", left == 0, left)
end

-- ==========================================================
-- SONUÇ
-- ==========================================================
print("=== SONUÇ ===")
print(string.format("kontrol sayısı: %d", totalChecks))
if #failures == 0 then
	print("TÜM TESTLER GEÇTİ")
else
	print(#failures .. " TEST BAŞARISIZ:")
	for _, f in ipairs(failures) do
		print("  x " .. f)
	end
end
if #mockWarnings > 0 then
	print("--- uyarılar (" .. #mockWarnings .. ") ---")
	for _, w in ipairs(mockWarnings) do
		print("  " .. w)
	end
end
if #failures > 0 then
	error("runtime test failed")
end
'''


def tool(name: str) -> pathlib.Path:
    for candidate in (
        HERE / name,
        HERE.parent / ".tools" / name,
        HERE.parent.parent / ".tools" / name,
    ):
        if candidate.exists():
            return candidate
    found = shutil.which(name)
    if found:
        return pathlib.Path(found)
    raise SystemExit(f"'{name}' bulunamadı: Luau CLI'yi <proje>/.tools/ içine koy.")


def build(admin_mode: bool) -> pathlib.Path:
    OUT.mkdir(exist_ok=True)

    # TEK dosya (teslim edilen) doğrudan test edilir.
    target = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else (ROOT / "XMENU_V52_CLIENT_UI.client.lua")
    body = target.read_text(encoding="utf-8")
    body = body.replace("--!strict\n", "", 1)
    # Luau CLI'da _G salt-okunur; Roblox'ta yazılabilir. Mock tablosuna bağla.
    body = body.replace("local sharedGlobals: any = _G", "local sharedGlobals: any = MOCK_GLOBALS")

    for svc in (
        "Players",
        "ReplicatedStorage",
        "SoundService",
        "Lighting",
        "Workspace",
        "UserInputService",
        "RunService",
        "TweenService",
        "StarterGui",
    ):
        body = body.replace(f'game:GetService("{svc}")', svc)

    admin_block = (
        "local LOCAL_ADMIN_USER_IDS: { [number]: boolean } = {\n"
        "\t-- [123456789] = true, -- ← KENDİ UserId'ni yaz\n"
        "}"
    )
    if admin_block not in body:
        raise SystemExit("admin listesi deseni bulunamadı (dosya değişti mi?)")
    if admin_mode:
        body = body.replace(
            admin_block,
            "local LOCAL_ADMIN_USER_IDS: { [number]: boolean } = { [MOCK_ADMIN_ID] = true }",
        )
    else:
        body = body.replace(
            admin_block,
            "local LOCAL_ADMIN_USER_IDS: { [number]: boolean } = {}",
        )

    chunk = (
        "\n;(function()\n"
        + "local ok, err = pcall(function()\n"
        + body
        + "\nUIKitModule = UIKit\n"  # test sürücüsü UIKit'e erişsin
        + "end)\n"
        + "if not ok then table.insert(mockWarnings, 'CHUNK ERROR: ' .. tostring(err)) end\n"
        + "end)()\n"
    )

    combined = MOCK + chunk + "\n" + TEST

    # Admin moduna göre LocalPlayer'ın UserId'sini ayarla
    if admin_mode:
        combined = combined.replace("LocalPlayer.UserId = 1", "LocalPlayer.UserId = MOCK_ADMIN_ID")

    # oyuncu listesi için "Ali" adlı bir oyuncu ekle
    combined = combined.replace(
        "table.insert(playersList, LocalPlayer)",
        """table.insert(playersList, LocalPlayer)
local Ali = Instance.new("Player")
Ali.Name = "Ali"
Ali.UserId = 77
Ali.CharacterAdded = newSignal()
Ali.Kick = function() end
table.insert(playersList, Ali)""",
    )

    out = OUT / f"runtime_test_{'admin' if admin_mode else 'user'}.luau"
    out.write_text(combined, encoding="utf-8")
    return out


def main() -> int:
    failed = False
    for admin_mode in (False, True):
        path = build(admin_mode)
        label = "ADMIN" if admin_mode else "OYUNCU"
        proc = subprocess.run([str(tool("luau")), str(path)], capture_output=True, text=True)
        print(f"----- MOD: {label} -----")
        print(proc.stdout.strip())
        if proc.stderr.strip():
            print("STDERR:", proc.stderr.strip()[:2000])
            failed = True
        if "TÜM TESTLER GEÇTİ" not in proc.stdout:
            failed = True
    print("\nRESULT:", "FAILED" if failed else "all clean")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
