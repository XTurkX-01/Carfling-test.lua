#!/usr/bin/env python3
"""
GitHub raw + loadstring için "host edilebilir" sürüm üretir.

Fark: dosyanın İLK SATIRI olan `--!strict` yönergesi kaldırılır.
  • `--!strict` yalnızca statik tip kontrolünü açar, RUNTIME davranışını etkilemez.
  • Bazı executor/loadstring bağlamlarında strict modlu bir chunk derlenemeyebilir;
    yönergesiz sürüm bu riski sıfırlar.
Geri kalan her şey birebir aynıdır (test edilmiş sürümün kopyası).
"""
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = ROOT / "XMENU_V52_CLIENT_UI.client.lua"
OUT = ROOT / "XMENU_V52_CLIENT_UI.raw.lua"

body = SRC.read_text(encoding="utf-8")

if not body.startswith("--!strict\n"):
    raise SystemExit("beklenen: dosya '--!strict' ile başlıyor")

body = body[len("--!strict\n") :]

header = (
    "-- X MENU V52 — CLIENT UI (GitHub raw / loadstring sürümü)\n"
    "-- Bu dosya XMENU_V52_CLIENT_UI.client.lua ile aynı koddur; yalnızca\n"
    "-- '--!strict' yönergesi (statik analiz bayrağı) kaldırılmıştır.\n"
    "-- Studio'ya koyacaksan strict'li orijinali kullan:\n"
    "--   XMENU_V52_CLIENT_UI.client.lua\n"
    "--\n"
    "-- Kullanım:\n"
    "--   loadstring(game:HttpGet(\"https://raw.githubusercontent.com/<user>/<repo>/<branch>/XMENU_V52_CLIENT_UI.raw.lua\"))()\n"
    "\n"
)

OUT.write_text(header + body, encoding="utf-8")
print(f"yazıldı: {OUT.name} ({len(OUT.read_text(encoding='utf-8').splitlines())} satır)")
